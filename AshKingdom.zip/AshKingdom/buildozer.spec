[app]
title = Пепел Забытого Королевства
package.name = ashkingdom
package.domain = org.ash
source.dir = .
source.include_exts = py
version = 1.0
requirements = python3,kivy==2.3.0
orientation = portrait
fullscreen = 1
android.api = 33
android.minapi = 24
android.archs = arm64-v8a
android.accept_sdk_license = True
[buildozer]
log_level = 2
warn_on_root = 1
