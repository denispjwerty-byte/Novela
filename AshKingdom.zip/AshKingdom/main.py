import json,io,base64,random,os
from kivy.app import App
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.image import Image
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.widget import Widget
from kivy.core.image import Image as CI
from kivy.core.window import Window
from kivy.graphics import Color,Rectangle,RoundedRectangle,Ellipse,Line
from kivy.graphics.texture import Texture
from kivy.animation import Animation
from kivy.clock import Clock
from kivy.metrics import dp,sp
import assets as A
Window.clearcolor=(0,0,0,1)
NM={'aren':('Арен','#7fb0ff'),'elir':('Элирия','#7be0a0'),'mira':('Мира','#b58cff'),'kael':('Каэль','#ff6a6a'),'edr':('Эдриан','#ff4d6d'),'lissa':('Лисса','#ff9a6a'),'oren':('Орен','#9db4c8'),'tar':('Тарвен','#d7c9ff'),'luc':('Люциан','#f1d98c'),'rein':('Рейна','#ff6a6a'),'nox':('Нокс','#a78bfa'),'gr':('Грегор','#d9a066'),'ast':('Астерион','#5ad0ff'),'gh':('Призрак','#bcd4e8'),'v':('Голос','#5ad0ff'),'mon':('Чудовище','#dd3333')}
SN={'el':'Доверие Элирии','mi':'Доверие Миры','ka':'Уважение Каэля','no':'Доверие Нокса','lu':'Союз с Люцианом','hu':'Человечность Арена','dk':'Тёмная сила','rp':'Репутация'}
POSE={'idle':(0,0,1),'lean':(.07,0,1.08),'tilt':(.02,-.02,1),'recoil':(-.07,0,.95),'rise':(0,.01,1.12),'fall':(0,-.06,1),'shake':(0,0,1),'glow':(0,0,1.03)}
PM={'idle':'down','shake':'down','glow':'cast','lean':'tilt','tilt':'tilt','recoil':'recoil','rise':'rise','fall':'fall'}
CAM={'wide':(1.08,0,1),'mid':(1.25,.03,1.05),'close':(1.5,.07,1.14)}
def hx(h):return tuple(int(h[i:i+2],16)/255 for i in (1,3,5))
def tex(b,ext,flip=False):
    t=CI(io.BytesIO(base64.b64decode(b)),ext=ext).texture
    if flip:t.flip_horizontal()
    return t
def rad(rgb,inv,n=48):
    b=bytearray()
    for y in range(n):
        for x in range(n):
            d=(((x-n/2)/(n/2))**2+((y-n/2)/(n/2))**2)**.5
            a=max(0,min(1,(d-.45)/.7)) if inv else max(0,1-d)
            b+=bytes((rgb[0],rgb[1],rgb[2],int(a**1.4*(215 if inv else 140))))
    t=Texture.create(size=(n,n),colorfmt='rgba');t.blit_buffer(bytes(b),colorfmt='rgba',bufferfmt='ubyte')
    t.mag_filter='linear';t.min_filter='linear';return t
class Sp:
    def __init__(s,root,k,side):
        s.k,s.side,s.gc=k,side,hx(NM[k][1]);s.c={};t=s.T('down');s.ar=t.height/t.width
        kw=dict(texture=t,size_hint=(None,None),fit_mode='fill')
        s.g=Image(color=(*s.gc,0),**kw);s.i=Image(color=(1,1,1,0),**kw)
        root.add_widget(s.g);root.add_widget(s.i)
    def T(s,p):
        if p not in s.c:s.c[p]=tex(A.CH[s.k][p],'png',s.side=='R')
        return s.c[p]
    def setp(s,p):
        t=s.T(p);s.i.texture=t;s.g.texture=t
    def move(s,sc,dx,dy,on,col=None,d=.6):
        W,H=Window.size;w=W*.68*sc;h=w*s.ar
        x=(-W*.08 if s.side=='L' else W*1.08-w)+dx*W*(1 if s.side=='L' else -1);y=H*.2+dy*H
        c=col or ((1,1,1,1) if on else (.36,.36,.42,1))
        Animation.cancel_all(s.i);Animation.cancel_all(s.g)
        Animation(pos=(x,y),size=(w,h),color=c,d=d,t='out_cubic').start(s.i)
        Animation(pos=(x-w*.03,y-h*.03),size=(w*1.06,h*1.06),color=(*s.gc,.4 if on else 0),d=d,t='out_cubic').start(s.g)
        return x,y
class Game(FloatLayout):
    def __init__(s,**k):
        super().__init__(**k)
        s.S=None;s.Q=[];s.ci=0;s.sp={};s.busy=True;s.typing=False;s.full='';s.ft='';s.P=[];s.fire=0;s.lock=True
        s.bg=Image(size_hint=(None,None),fit_mode='cover',opacity=0);s.add_widget(s.bg)
        s.st=FloatLayout();s.add_widget(s.st)
        s.fxw=Widget();s.add_widget(s.fxw)
        s.tw=Widget()
        with s.tw.canvas:
            s.tc=Color(0,0,0,0);s.tr=Rectangle()
            s.fc=Color(1,.55,.2,0);s.fr=Rectangle(texture=rad((255,140,50),False))
            Color(1,1,1,1);s.vr=Rectangle(texture=rad((2,1,8),True))
        s.add_widget(s.tw)
        s.box=FloatLayout(size_hint=(.94,.27),pos_hint={'center_x':.5,'y':.025})
        with s.box.canvas.before:
            Color(.04,.03,.09,.92);s.br=RoundedRectangle(radius=[dp(14)]*4)
            Color(.85,.72,.47,.6);s.bl=Line(width=1)
        s.box.bind(pos=s.rb,size=s.rb)
        s.tx=Label(size_hint=(.92,.8),pos_hint={'x':.04,'top':.9},halign='left',valign='top',font_size=sp(16),color=(.95,.93,.98,1))
        s.tx.bind(size=lambda w,v:setattr(w,'text_size',(v[0],v[1])))
        s.box.add_widget(s.tx);s.add_widget(s.box)
        s.nm=Label(size_hint=(None,None),size=(dp(130),dp(30)),pos_hint={'x':.06,'y':.285},bold=True,font_size=sp(17))
        with s.nm.canvas.before:
            Color(.04,.03,.09,1);s.nr=RoundedRectangle(radius=[dp(8)]*4)
        s.nm.bind(pos=lambda w,v:setattr(s.nr,'pos',v),size=lambda w,v:setattr(s.nr,'size',v));s.add_widget(s.nm)
        s.mb=Button(text='=',size_hint=(None,None),size=(dp(42),dp(42)),pos_hint={'right':.98,'top':.985},background_normal='',background_color=(.05,.03,.1,.8),color=(.85,.72,.47,1),on_release=lambda b:s.menu())
        s.add_widget(s.mb)
        s.bind(size=s.lay);Clock.schedule_interval(s.tick,1/30);Clock.schedule_interval(s.type,.022);Clock.schedule_interval(s.flick,.12)
        s.title();s.lay()
    def rb(s,*a):
        b=s.box;s.br.pos=b.pos;s.br.size=b.size;s.bl.rounded_rectangle=(b.x,b.y,b.width,b.height,dp(14))
    def lay(s,*a):
        for r in (s.tr,s.fr,s.vr):r.pos=(0,0);r.size=Window.size
        s.bg.size=Window.size
    # ---- screens
    def overlay(s,color=(.01,.01,.04,.96)):
        o=FloatLayout()
        with o.canvas.before:
            Color(*color);r=Rectangle()
        o.bind(pos=lambda w,v:setattr(r,'pos',v),size=lambda w,v:setattr(r,'size',v));s.add_widget(o);s.lock=True;return o
    def lab(s,o,t,fs,y,col=(.85,.72,.47,1),**k):
        o.add_widget(Label(text=t,font_size=sp(fs),color=col,pos_hint={'center_x':.5,'center_y':y},halign='center',size_hint=(.9,None),text_size=(Window.width*.9,None),**k))
    def btn(s,o,t,y,f):
        o.add_widget(Button(text=t,size_hint=(.78,None),height=dp(52),pos_hint={'center_x':.5,'center_y':y},background_normal='',background_color=(.25,.17,.45,.9),font_size=sp(17),on_release=lambda b:f()))
    def title(s):
        o=s.overlay();s.lab(o,'ПЕПЕЛ ЗАБЫТОГО\nКОРОЛЕВСТВА',30,.7,bold=True)
        s.btn(o,'Новая игра',.45,lambda:(s.remove_widget(o),s.begin(None,0)))
        d=s.load()
        if d:s.btn(o,'Продолжить',.34,lambda:(s.remove_widget(o),s.begin(d['S'],d['ci'])))
    def menu(s):
        if s.S is None or s.lock and s.busy and not s.typing and not s.Q:return
        o=s.overlay();t=''
        for k,n in SN.items():v=s.S['st'][k];t+='%s: %d\n'%(n,v)
        s.lab(o,'Ваш путь',26,.85,bold=True);s.lab(o,t,17,.55,col=(.9,.9,1,1))
        s.btn(o,'Вернуться',.22,lambda:(s.remove_widget(o),setattr(s,'lock',s.busy and False)))
        s.btn(o,'В главное меню',.12,lambda:(s.remove_widget(o),s.title()))
    # ---- save
    def path(s):return os.path.join(App.get_running_app().user_data_dir,'s.json')
    def save(s):
        try:json.dump({'S':s.S,'ci':s.ci},open(s.path(),'w'))
        except Exception:pass
    def load(s):
        try:return json.load(open(s.path()))
        except Exception:return None
    # ---- flow
    def begin(s,S,ci):
        s.S=S or {'st':{k:0 for k in SN},'fl':{}};s.ci=ci;s.chap()
    def chap(s):
        if s.ci>=len(A.STORY):
            o=s.overlay();s.lab(o,'Конец',28,.6,bold=True);s.lab(o,'Спасибо за игру',16,.5);s.btn(o,'Статистика',.3,lambda:(s.remove_widget(o),s.menu()));return
        s.Q=list(A.STORY[s.ci]);s.save();s.lock=False;s.busy=False;s.step()
    def on_touch_down(s,t):
        if s.lock or s.mb.collide_point(*t.pos):return super().on_touch_down(t)
        if s.typing:s.tx.text=s.full;s.typing=False;return True
        if not s.busy:s.step()
        return True
    def card(s,a,b,cb):
        o=s.overlay((0,0,0,1));s.lab(o,a,18,.56);s.lab(o,b,32,.45,bold=True);o.opacity=0
        Animation(opacity=1,d=.7).start(o)
        def out(dt):Animation(opacity=0,d=.7).start(o);Clock.schedule_once(lambda d:(s.remove_widget(o),setattr(s,'lock',False),cb()),.75)
        Clock.schedule_once(out,2)
    def step(s):
        if s.busy:return
        if not s.Q:s.ci+=1;return s.chap()
        x=s.Q.pop(0)
        if 'card' in x:s.busy=True;return s.card(x['card'],x['sub'],lambda:(setattr(s,'busy',False),s.step()))
        if 'end' in x:s.busy=True;return s.card('Конец главы','',lambda:(setattr(s,'busy',False),setattr(s,'ci',s.ci+1),s.chap()))
        if 'bg' in x:return s.setbg(x)
        if 'sh' in x:
            for k,d in x['sh'].items():s.put(k,d)
            return s.step()
        if 'if' in x:
            st,th=x['if'];v=s.S['fl'].get(st[2:],0) if st[:2]=='f:' else s.S['st'][st];s.Q[0:0]=x['a'] if v>=th else x['b'];return s.step()
        if 'ch' in x:return s.choose(x['ch'])
        s.say(x)
    def setbg(s,x):
        s.busy=True;s.fire=1 if x.get('fire') else 0
        for v in s.sp.values():s.st.remove_widget(v.g);s.st.remove_widget(v.i)
        s.sp={};s.fxset(x.get('fx'));s.tc.rgba=(*hx(x['tn']),.28) if x.get('tn') else (0,0,0,0)
        def sw(dt):
            s.bg.texture=tex(A.BG[x['bg']],'jpg');s.cam('wide',None);Animation(opacity=1,d=.7).start(s.bg)
            Clock.schedule_once(lambda d:(setattr(s,'busy',False),s.step()),.5)
        Animation(opacity=0,d=.6).start(s.bg);Clock.schedule_once(sw,.65)
    def put(s,k,side):
        s.sp[k]=Sp(s.st,k,side);s.sp[k].move(1,0,0,False,d=.01);s.lay_sp(None)
    def cam(s,n,spk,pose=None):
        W,H=Window.size;z,sh,sc=CAM[n or 'mid'];d=-1 if (spk in s.sp and s.sp[spk].side=='R') else 1
        w,h=W*z,H*z
        Animation(size=(w,h),pos=(-(w-W)/2-d*sh*W,-(h-H)*.35),d=1.6,t='out_cubic').start(s.bg)
        s.csc=sc;s.lay_sp(spk,pose)
    def lay_sp(s,spk,pose=None):
        for k,v in s.sp.items():
            on=k==spk
            if on:v.setp(PM.get(pose or 'idle','down'))
            dx,dy,ps=POSE.get(pose or 'idle') if on else (0,0,1)
            x,y=v.move(getattr(s,'csc',1)*(ps if on else .94),dx,dy,on,(.6,.95,1,1) if on and pose=='glow' else None)
            if on and pose=='shake':
                a=Animation(x=x,d=.01)
                for i in range(4):a+=Animation(x=x+dp(9),d=.04)+Animation(x=x-dp(9),d=.04)
                a+=Animation(x=x,d=.04);Clock.schedule_once(lambda dt,a=a,im=v.i:a.start(im),.65)
    def say(s,x):
        w=x.get('w')
        if w in A.CH and w not in s.sp:
            if len(s.sp)>=2:
                o=next(k for k in s.sp if k!=w);v=s.sp.pop(o);s.st.remove_widget(v.g);s.st.remove_widget(v.i)
            s.put(w,'R' if any(v.side=='L' for v in s.sp.values()) else 'L')
        s.cam(x.get('cam'),w,x.get('p'))
        if x.get('sk'):
            b=s.bg;a=Animation(x=b.x+dp(12),d=.05)+Animation(x=b.x-dp(12),d=.05)+Animation(x=b.x+dp(7),d=.05)
            Clock.schedule_once(lambda dt:a.start(b),.05)
        n=x.get('n') or (NM[w][0] if w in NM else '');s.nm.opacity=1 if n else 0;s.nm.text=n
        s.nm.color=hx(NM[w][1]) if w in NM else (.8,.8,.8,1)
        s.tx.italic=not w;s.full=x['t'];s.tx.text='';s.n=0;s.typing=True
    def type(s,dt):
        if s.typing:
            s.n+=1;s.tx.text=s.full[:s.n]
            if s.n>=len(s.full):s.typing=False
    def choose(s,opts):
        s.busy=True;o=s.overlay((0,0,0,.62));box=BoxLayout(orientation='vertical',spacing=dp(10),size_hint=(.9,None),height=len(opts)*dp(66),pos_hint={'center_x':.5,'center_y':.5})
        def pick(x):
            for k,v in x.get('e',{}).items():s.S['st'][k]+=v
            if x.get('f'):s.S['fl'][x['f']]=1
            s.remove_widget(o);s.lock=False;s.busy=False;s.Q[0:0]=x['r'];s.step()
        for x in opts:
            b=Button(text=x['t'],background_normal='',background_color=(.24,.16,.44,.95),font_size=sp(16),halign='left',valign='middle',on_release=lambda b,x=x:pick(x))
            b.bind(size=lambda w,v:setattr(w,'text_size',(v[0]-dp(20),None)));box.add_widget(b)
        o.add_widget(box)
    # ---- fx
    def fxset(s,t):
        s.fxw.canvas.clear();s.P=[];s.ft=t or ''
        col={'rain':(.67,.75,1,.35),'ember':(1,.55,.2,.7),'fly':(.75,1,.6,.7),'ash':(.86,.47,.5,.5),'dust':(1,.95,.86,.3)}.get(t)
        if not col:return
        W,H=Window.size
        with s.fxw.canvas:
            for i in range({'rain':90,'ember':40,'fly':28,'ash':45,'dust':30}[t]):
                c=Color(*col);sh=Line(points=[0,0,0,0],width=1) if t=='rain' else Ellipse(size=(dp(random.uniform(2,5)),)*2)
                s.P.append([random.random()*W,random.random()*H,random.random()+.5,random.random()*6,sh,c])
    def tick(s,dt):
        W,H=Window.size;t=s.ft
        for p in s.P:
            p[3]+=.03
            if t=='rain':p[1]-=p[2]*H*.03;p[0]-=3
            elif t=='ember':p[1]+=p[2];p[0]+=random.uniform(-1,1)
            elif t=='ash':p[1]-=p[2]*.8;p[0]+=random.uniform(-1,1)
            else:p[1]+=random.uniform(-.5,.5)-(.2 if t=='dust' else 0);p[0]+=random.uniform(-.5,.5)
            if p[1]<-20:p[1]=H+10
            if p[1]>H+20:p[1]=-5
            if t=='rain':p[4].points=[p[0],p[1],p[0]+3,p[1]+dp(16)]
            else:p[4].pos=(p[0],p[1])
    def flick(s,dt):s.fc.a=random.uniform(.35,.8) if s.fire else 0
class AshApp(App):
    def build(s):return Game()
AshApp().run()
