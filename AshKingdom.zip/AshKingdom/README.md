# Пепел Забытого Королевства (Kivy, Android)
Сборка APK: загрузите папку в репозиторий GitHub, откройте Actions -> Build APK -> Run workflow.
APK появится в Artifacts (15-30 минут).
Файлы: main.py (игра), assets.py (картинки и сюжет, вшиты), buildozer.spec, .github/workflows/build.yml.
Папка art/ содержит те же картинки в виде файлов для справки и замены (в сборку не входит).
